"clinical_data.txt" is a .txt table with the following variables:

    gender (0 = male, 1 = female)
    age (years)
    body mass index (Kg/m2)
    basal glycaemia (mg/dL)
    HbA1c (%)
    follow-up (days)
    final diagnosis of type 2 diabetes mellitus 

Files from "case 1.csv" to "case 208.csv" are the CGMS record of patients included in the study (in the same order as  in "clinical_data.txt"), with two columns:

    time
    interstitial glucose
